import { ParsedJD, ParsedResume } from "../types";

const weakVerbs = ["responsible for", "helped", "assisted", "supporting", "worked on"];
const passiveRegex = /\b(was|were|been|being|be)\s+\w+ed\b/i;

export function buildSuggestions(jd: ParsedJD, resume: ParsedResume) {
  const missingSkills = jd.requiredSkills.filter((s) => !resume.skills.includes(s));
  const keywordsToAdd = jd.keywords.filter(
    (k) => !(resume.summary || "").toLowerCase().includes(k.toLowerCase())
  );

  const bulletIssues: string[] = [];
  resume.experiences.forEach((exp) => {
    exp.bullets.forEach((b) => {
      const cleaned = b.trim();
      const wordCount = cleaned.split(/\s+/).length;
      if (cleaned && !/\d/.test(cleaned)) {
        bulletIssues.push(`Add a metric to "${cleaned.slice(0, 80)}..."`);
      }
      if (wordCount > 30) {
        bulletIssues.push(`Shorten long bullet (${wordCount} words): "${cleaned.slice(0, 80)}..."`);
      }
      if (weakVerbs.some((w) => cleaned.toLowerCase().startsWith(w))) {
        bulletIssues.push(`Use a stronger action verb instead of "${cleaned.slice(0, 25)}..."`);
      }
      if (passiveRegex.test(cleaned)) {
        bulletIssues.push(`Rewrite passive voice: "${cleaned.slice(0, 80)}..."`);
      }
    });
  });

  const missingSections: string[] = [];
  const sectionsPresent = resume.flags?.sectionsPresent;
  if (sectionsPresent) {
    if (!sectionsPresent.projects) missingSections.push("Projects (add 1–2 bullets tied to JD keywords)");
    if (!sectionsPresent.education) missingSections.push("Education");
    if (!sectionsPresent.skills) missingSections.push("Skills (curate to JD core/keywords)");
    if (!sectionsPresent.summary) missingSections.push("Summary (title + years + core skills + metric)");
  }

  const formatFlags: string[] = [];
  if (resume.flags?.hasColumns) formatFlags.push("Columns detected; ATS may struggle");
  if (resume.flags?.hasImages) formatFlags.push("Images detected; remove graphics for ATS");

  const summaryHint =
    missingSkills.length || !resume.summary
      ? `Add summary with title + years + top skills (${missingSkills.slice(0, 5).join(", ")}) and one metric.`
      : "Summary covers core skills.";

  return {
    missingSkills,
    keywordsToAdd,
    bulletIssues,
    summaryHint,
    missingSections,
    formatFlags,
  };
}

