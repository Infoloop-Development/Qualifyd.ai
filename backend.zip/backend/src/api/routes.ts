import express from "express";
import multer from "multer";
import { jobStore } from "./store";
import { processJob } from "./service";
import { rewriteWithGemini } from "../ai/gemini";

export const router = express.Router();

// Types are loose to keep scaffolding simple.
const upload = multer();

router.post(
  "/analyze",
  upload.single("resume_file"),
  async (req: express.Request, res: express.Response) => {
    const jdText = (req.body.jd_text as string) || "";
    const file = req.file;

    if (!jdText || !file) {
      return res.status(400).json({ error: "jd_text and resume_file are required" });
    }

    const job = jobStore.create({ jdText, file });
    // Fire and forget for now; later swap to BullMQ/worker
    processJob(job).catch((err) => {
      jobStore.fail(job.id, err);
    });

    res.json({ job_id: job.id });
  }
);

router.get("/status/:jobId", (req, res) => {
  const job = jobStore.get(req.params.jobId);
  if (!job) return res.status(404).json({ error: "job not found" });
  res.json(job);
});

router.post("/rewrite", async (req, res) => {
  if (!process.env.GEMINI_API_KEY) {
    return res.status(503).json({ error: "Gemini is disabled (GEMINI_API_KEY not set)" });
  }
  try {
    const body = req.body || {};
    const result = await rewriteWithGemini({
      jdKeywords: body.jdKeywords,
      jdSkills: body.jdSkills,
      summary: body.summary,
      bullets: body.bullets,
    });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: (err as Error).message });
  }
});

