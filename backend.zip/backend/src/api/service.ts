import { jobStore } from "./store";
import { extractText } from "../parsers/textExtraction";
import { parseJD } from "../parsers/jdParser";
import { parseResume } from "../parsers/resumeParser";
import { scoreAll } from "../scoring/scoreEngine";
import { buildSuggestions } from "../suggestions/suggestionsEngine";
import { logger } from "../utils/logger";

export async function processJob(job: { id: string; jdText: string; file?: Express.Multer.File }) {
  jobStore.start(job.id);

  if (!job.file) {
    throw new Error("Missing file");
  }

  const resumeText = await extractText(job.file);
  const parsedJD = parseJD(job.jdText);
  const parsedResume = parseResume(resumeText);
  const scores = scoreAll(parsedJD, parsedResume);
  const suggestions = buildSuggestions(parsedJD, parsedResume);

  jobStore.complete(job.id, {
    result: { scores, suggestions },
    parsed: { jd: parsedJD, resume: parsedResume },
  });

  logger.info({ jobId: job.id }, "job completed");
}

