import { useMemo, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  analyzeResume,
  fetchJobStatus,
  requestRewrite,
  type JobStatusResponse,
  type RewriteResponse,
} from "./api";

function ScoreCard({ label, value }: { label: string; value?: number }) {
  return (
    <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
      <p className="text-sm text-slate-500">{label}</p>
      <p className="text-3xl font-semibold text-slate-900">{value ?? "—"}</p>
    </div>
  );
}

function App() {
  const [jdText, setJdText] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [jobId, setJobId] = useState<string | null>(null);
  const [rewriteResult, setRewriteResult] = useState<RewriteResponse | null>(null);

  const analyzeMutation = useMutation({
    mutationFn: async () => {
      if (!file) throw new Error("Select a resume file first");
      return analyzeResume(jdText, file);
    },
    onSuccess: (data) => {
      setJobId(data.job_id);
    },
  });

  const { data: statusData } = useQuery<JobStatusResponse>({
    queryKey: ["status", jobId],
    queryFn: () => fetchJobStatus(jobId!),
    enabled: !!jobId,
    refetchInterval: (data) =>
      !data || data.status === "queued" || data.status === "processing" ? 1500 : false,
  });

  const isLoading =
    analyzeMutation.isPending ||
    statusData?.status === "queued" ||
    statusData?.status === "processing";

  const suggestions = statusData?.result?.suggestions;
  const scores = statusData?.result?.scores;
  const hasResults = statusData?.status === "done" && !!statusData?.result;

  const missingSkills = useMemo(() => suggestions?.missingSkills || [], [suggestions]);
  const keywordsToAdd = useMemo(() => suggestions?.keywordsToAdd || [], [suggestions]);
  const bulletIssues = useMemo(() => suggestions?.bulletIssues || [], [suggestions]);
  const missingSections = useMemo(() => suggestions?.missingSections || [], [suggestions]);
  const formatFlags = useMemo(() => suggestions?.formatFlags || [], [suggestions]);

  const rewriteMutation = useMutation({
    mutationFn: async () => {
      if (!suggestions) throw new Error("Run analysis first");
      return requestRewrite({
        jdKeywords: suggestions.keywordsToAdd ?? [],
        jdSkills: [...(suggestions.missingSkills ?? []), ...(suggestions.keywordsToAdd ?? [])],
        summary: statusData?.parsed?.resume?.summary || "",
        bullets: bulletIssues.slice(0, 5),
      });
    },
    onSuccess: (data) => setRewriteResult(data),
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="border-b border-slate-200 bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-4 sm:px-6">
          <div>
            <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-indigo-600">Beta</p>
            <h1 className="text-lg font-semibold text-slate-900 sm:text-xl">Resume ↔ JD Analyzer</h1>
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600 sm:text-sm">
            <span className="rounded-full bg-slate-100 px-3 py-1">Deterministic by default</span>
            <span className="rounded-full bg-slate-100 px-3 py-1">Optional AI rewrite</span>
          </div>
        </div>
      </div>

      <div className="mx-auto flex max-w-5xl flex-col gap-6 px-4 py-6 sm:px-6">

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="space-y-3 lg:col-span-2">
          <label className="text-sm font-medium text-slate-700">Job Description</label>
          <textarea
            className="h-56 w-full rounded-lg border border-slate-200 bg-white p-3 text-sm shadow-sm focus:border-indigo-500 focus:outline-none"
            placeholder="Paste the JD text here..."
            value={jdText}
            onChange={(e) => setJdText(e.target.value)}
          />
        </div>

        <div className="space-y-3">
          <label className="text-sm font-medium text-slate-700">Resume (PDF/DOCX)</label>
          <div className="flex h-56 flex-col items-center justify-center rounded-lg border border-dashed border-slate-300 bg-white p-4 text-center shadow-sm">
            <input
              type="file"
              accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) setFile(f);
              }}
            />
            <p className="mt-2 text-sm text-slate-500">
              {file ? `Selected: ${file.name}` : "Choose a PDF or DOCX file (max ~5MB)."}
            </p>
          </div>

          <button
            className="w-full rounded-lg bg-indigo-600 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-500 disabled:cursor-not-allowed disabled:bg-slate-300"
            onClick={() => analyzeMutation.mutate()}
            disabled={!jdText || !file || analyzeMutation.isPending}
          >
            {analyzeMutation.isPending ? "Submitting..." : "Analyze"}
          </button>

          {analyzeMutation.error && (
            <p className="text-sm text-red-600">{(analyzeMutation.error as Error).message}</p>
          )}
          {jobId && <p className="text-xs text-slate-500">Job ID: {jobId}</p>}
          {isLoading && <p className="text-sm text-slate-600">Processing…</p>}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <section className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm space-y-2" id="overview">
          <h2 className="text-lg font-semibold text-slate-900">Overview</h2>
          <p className="text-sm text-slate-700">
            Resume ↔ JD analyzer that parses both, scores Fit/ATS/Writing, and delivers actionable, rule-based
            improvements with an optional AI rewrite step.
          </p>
        </section>

        <section className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm space-y-2">
          <h2 className="text-lg font-semibold text-slate-900">How it works</h2>
          <ol className="list-decimal pl-5 space-y-1 text-sm text-slate-700">
            <li>Paste JD and upload PDF/DOCX.</li>
            <li>Text extraction + section/skill/keyword detection.</li>
            <li>Deterministic scoring for Fit, ATS, Writing.</li>
            <li>Surface gaps: missing skills/sections, bullet issues, format flags.</li>
            <li>Optional AI rewrite for summary/bullets (only if you click it).</li>
          </ol>
        </section>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <section className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm space-y-2">
          <h2 className="text-lg font-semibold text-slate-900">What you get</h2>
          <ul className="list-disc pl-5 space-y-1 text-sm text-slate-700">
            <li>Fit / ATS / Writing scores</li>
            <li>Missing skills and keywords to add</li>
            <li>Missing sections (Summary, Skills, Projects, Education)</li>
            <li>Bullet/style issues (no metrics, weak verbs, passive voice, too long)</li>
            <li>Formatting flags (columns/images if detected)</li>
            <li>Summary hint; optional AI rewrites (clearly labeled)</li>
          </ul>
        </section>

        <section className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm space-y-2" id="privacy">
          <h2 className="text-lg font-semibold text-slate-900">Privacy & control</h2>
          <ul className="list-disc pl-5 space-y-1 text-sm text-slate-700">
            <li>Deterministic processing by default; no AI unless you request it.</li>
            <li>AI rewrite sends only needed text to Gemini; requires your key.</li>
            <li>Skip AI rewrite anytime; core results stay rule-based.</li>
          </ul>
        </section>
      </div>

      <section className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm space-y-2" id="how-to-use">
        <h2 className="text-lg font-semibold text-slate-900">How to use</h2>
        <ol className="list-decimal pl-5 space-y-1 text-sm text-slate-700">
          <li>Paste JD text.</li>
          <li>Upload your resume (PDF/DOCX).</li>
          <li>Click Analyze and wait for processing.</li>
          <li>Review scores and suggestions; optionally click “AI rewrite (Gemini)”.</li>
        </ol>
      </section>

      {hasResults && (
        <>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
            <ScoreCard label="Fit Score" value={scores?.fit} />
            <ScoreCard label="ATS Score" value={scores?.ats} />
            <ScoreCard label="Writing Score" value={scores?.writing} />
          </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-800">Missing Skills</h3>
          <ul className="mt-2 space-y-1 text-sm text-slate-700">
            {missingSkills.length ? (
              missingSkills.map((s) => <li key={s}>• {s}</li>)
            ) : (
              <li className="text-slate-500">None detected</li>
            )}
          </ul>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-800">Keywords to Add</h3>
          <ul className="mt-2 space-y-1 text-sm text-slate-700">
            {keywordsToAdd.length ? (
              keywordsToAdd.map((k) => <li key={k}>• {k}</li>)
            ) : (
              <li className="text-slate-500">None detected</li>
            )}
          </ul>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-800">Missing Sections</h3>
          <ul className="mt-2 space-y-1 text-sm text-slate-700">
            {missingSections.length ? (
              missingSections.map((s) => <li key={s}>• {s}</li>)
            ) : (
              <li className="text-slate-500">All core sections present</li>
            )}
          </ul>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-slate-800">Formatting Flags</h3>
          <ul className="mt-2 space-y-1 text-sm text-slate-700">
            {formatFlags.length ? (
              formatFlags.map((f, idx) => <li key={idx}>• {f}</li>)
            ) : (
              <li className="text-slate-500">No format issues detected</li>
            )}
          </ul>
        </div>
      </div>

      <div className="rounded-lg border border-slate-200 bg-white p-4 shadow-sm">
        <h3 className="text-sm font-semibold text-slate-800">Bullet & Style Issues</h3>
        <ul className="mt-2 space-y-2 text-sm text-slate-700">
          {bulletIssues.length ? (
            bulletIssues.map((b, idx) => <li key={idx}>• {b}</li>)
          ) : (
            <li className="text-slate-500">No bullet issues flagged.</li>
          )}
        </ul>
        {suggestions?.summaryHint && (
          <p className="mt-3 text-sm text-slate-600">
            <span className="font-semibold">Summary hint: </span>
            {suggestions.summaryHint}
          </p>
        )}
        <div className="mt-4 flex items-center gap-3">
          <button
            className="rounded-lg bg-emerald-600 px-3 py-2 text-white shadow-sm transition hover:bg-emerald-500 disabled:cursor-not-allowed disabled:bg-slate-300"
            onClick={() => rewriteMutation.mutate()}
            disabled={!suggestions || rewriteMutation.isPending}
          >
            {rewriteMutation.isPending ? "AI rewriting…" : "AI rewrite (Gemini)"}
          </button>
          {rewriteMutation.error && (
            <span className="text-sm text-red-600">{(rewriteMutation.error as Error).message}</span>
          )}
        </div>
        {rewriteResult && (
          <div className="mt-4 space-y-2">
            {rewriteResult.summary && (
              <p className="text-sm text-slate-700">
                <span className="font-semibold">AI Summary: </span>
                {rewriteResult.summary}
              </p>
            )}
            {rewriteResult.bullets?.length ? (
              <div>
                <p className="text-sm font-semibold text-slate-800">AI Bullet Suggestions</p>
                <ul className="mt-1 space-y-1 text-sm text-slate-700">
                  {rewriteResult.bullets.map((b, idx) => (
                    <li key={idx}>• {b}</li>
                  ))}
                </ul>
              </div>
            ) : null}
          </div>
        )}
      </div>
        </>
      )}
      </div>

      <footer className="mt-8 border-t border-slate-200 bg-white/60 backdrop-blur">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-6 py-4 text-sm text-slate-600">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-semibold text-slate-800">Resume ↔ JD Analyzer</span>
            <span className="text-slate-400">|</span>
            <span>Rule-based scoring with optional AI rewrites</span>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <a className="hover:text-indigo-600" href="#how-to-use">How to use</a>
            <a className="hover:text-indigo-600" href="#privacy">Privacy</a>
            <a className="hover:text-indigo-600" href="#overview">Overview</a>
          </div>
        </div>
        <div className="mx-auto max-w-6xl px-6 pb-4 text-xs text-slate-500 sm:px-6">
          Made with love, open-source and free for the community by QuirkBees Technologies LLP.
        </div>
      </footer>
    </div>
  );
}

export default App;
