const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:4000/api";

export interface AnalyzeResponse {
  job_id: string;
}

export type JobStatus = "queued" | "processing" | "failed" | "done";

export interface JobStatusResponse {
  status: JobStatus;
  error?: string;
  result?: {
    scores: {
      fit: number;
      ats: number;
      writing: number;
      breakdown: Record<string, number>;
    };
    suggestions: {
      missingSkills: string[];
      keywordsToAdd: string[];
      bulletIssues: string[];
      summaryHint: string;
      missingSections: string[];
      formatFlags: string[];
    };
  };
  parsed?: {
    resume?: {
      summary?: string;
    };
    jd?: unknown;
  };
}

export interface RewriteRequest {
  jdKeywords?: string[];
  jdSkills?: string[];
  summary?: string;
  bullets?: string[];
}

export interface RewriteResponse {
  summary?: string;
  bullets?: string[];
}

export async function analyzeResume(jdText: string, file: File): Promise<AnalyzeResponse> {
  const form = new FormData();
  form.append("jd_text", jdText);
  form.append("resume_file", file);

  const res = await fetch(`${API_BASE}/analyze`, {
    method: "POST",
    body: form,
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || "Failed to submit analysis");
  }
  return res.json();
}

export async function fetchJobStatus(jobId: string): Promise<JobStatusResponse> {
  const res = await fetch(`${API_BASE}/status/${jobId}`);
  if (!res.ok) {
    throw new Error("Failed to fetch job status");
  }
  return res.json();
}

export async function requestRewrite(payload: RewriteRequest): Promise<RewriteResponse> {
  const res = await fetch(`${API_BASE}/rewrite`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || "Rewrite failed");
  }
  return res.json();
}

